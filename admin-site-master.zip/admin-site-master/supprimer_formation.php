<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Supprimer une Formation</title>
    <link rel="stylesheet" href="styles.css">
    <script src="scripts.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Supprimer une Formation</h1>
        <?php
        $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $sql = "DELETE FROM courses WHERE id=$id";
            if ($conn->query($sql) === TRUE) {
                echo "Formation supprimée avec succès.";
            } else {
                echo "Erreur: " . $sql . "<br>" . $conn->error;
            }
        }
        ?>
        <a href="liste_formations.php">Retour à la liste des formations</a>
    </div>
</body>
</html>
