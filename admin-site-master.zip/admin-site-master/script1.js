// script.js

document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.querySelector('#sidebar');
    const sidebarToggle = document.querySelector('.btn-upgrade');

    sidebarToggle.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
    });

    const progressBars = document.querySelectorAll('.progress');
    progressBars.forEach(bar => {
        const value = bar.getAttribute('data-value');
        bar.style.width = value;
    });
});
