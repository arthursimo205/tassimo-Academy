<?php
// liste_utilisateurs.php
session_start();
$conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch users from database
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style.css">
    <title>Liste des Utilisateurs</title>
</head>
<body>
<section id="sidebar">
    <!-- Sidebar code remains the same -->
</section>

<section id="content">
    <nav>
        <!-- Navbar code remains the same -->
    </nav>

    <main>
        <h1 class="title">Liste des Utilisateurs</h1>
        <ul class="breadcrumbs">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li class="divider">/</li>
            <li><a href="#" class="active">Utilisateurs</a></li>
        </ul>
        <div class="data">
            <div class="content-data">
                <div class="head">
                    <h3>Utilisateurs</h3>
                </div>
                <div class="table">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nom</th>
                                <th>Email</th>
                                <th>WhatsApp</th>
                                <th>Date de Création</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['id']; ?></td>
                                <td><?= $row['username']; ?></td>
                                <td><?= $row['email']; ?></td>
                                <td><?= $row['whatsapp']; ?></td>
                                <td><?= $row['creation_date']; ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>
</section>

<script src="script.js"></script>
</body>
</html>
