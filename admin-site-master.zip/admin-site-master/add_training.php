<?php
// add_training.php

// Database connection
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $registration_deadline = $_POST['registration_deadline'];
    $start_date = $_POST['start_date'];
    
    // Handle file upload
    $flyer = '';
    if (isset($_FILES['flyer']) && $_FILES['flyer']['error'] == 0) {
        $upload_dir = 'uploads/';
        $upload_file = $upload_dir . basename($_FILES['flyer']['name']);
        move_uploaded_file($_FILES['flyer']['tmp_name'], $upload_file);
        $flyer = basename($_FILES['flyer']['name']);
    }

    $sql = "INSERT INTO in_person_training (title, description, flyer, price, registration_deadline, start_date) 
            VALUES ('$title', '$description', '$flyer', $price, '$registration_deadline', '$start_date')";

    if ($conn->query($sql) === TRUE) {
        echo "Formation ajoutée avec succès!";
    } else {
        echo "Erreur: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter formation presentiel</title>
    <link rel="stylesheet" href="stylespres.css">
</head>
<body>

<form action="add_training.php" method="post" enctype="multipart/form-data">
    <label for="title">Titre:</label>
    <input type="text" id="title" name="title" required>
    <label for="description">Description:</label>
    <textarea id="description" name="description" required></textarea>
    <label for="flyer">Flyer:</label>
    <input type="file" id="flyer" name="flyer">
    <label for="price">Prix d'inscription:</label>
    <input type="number" id="price" name="price" step="0.01" required>
    <label for="registration_deadline">Date limite d'inscription:</label>
    <input type="date" id="registration_deadline" name="registration_deadline" required>
    <label for="start_date">Date de début:</label>
    <input type="date" id="start_date" name="start_date" required>
    <input type="submit" value="Ajouter Formation">
</form>

</body>
</html>
