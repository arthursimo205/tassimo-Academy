<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Supprimer une Catégorie</title>
    <link rel="stylesheet" href="styles.css">
    <script src="scripts.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Supprimer une Catégorie</h1>
        <?php
        $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $sql = "DELETE FROM categories WHERE id=$id";
            if ($conn->query($sql) === TRUE) {
                echo "Catégorie supprimée avec succès.";
            } else {
                echo "Erreur: " . $sql . "<br>" . $conn->error;
            }
        }
        ?>
        <a href="liste_categories.php">Retour à la liste des catégories</a>
    </div>
</body>
</html>
