<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajouter une Catégorie</title>
    <link rel="stylesheet" href="styles1.css">
    <script src="scripts.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Ajouter une Catégorie</h1>
        <form action="ajouter_categorie.php" method="POST">
            <label for="name">Nom de la catégorie:</label>
            <input type="text" id="name" name="name" required>
            <button type="submit" name="submit">Ajouter</button>
        </form>
    </div>
    <?php
    if (isset($_POST['submit'])) {
        $name = $_POST['name'];

        // Connexion à la base de données
        $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "INSERT INTO category (name) VALUES ('$name')";
        if ($conn->query($sql) === TRUE) {
            echo "Catégorie ajoutée avec succès.";
        } else {
            echo "Erreur: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }
    ?>
</body>
</html>
