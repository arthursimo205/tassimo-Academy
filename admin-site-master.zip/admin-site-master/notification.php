<?php
// notification.php

// Récupérer les données envoyées par l'API de paiement
$data = file_get_contents('php://input');
$payment_info = json_decode($data, true);

// Assurez-vous que les données sont correctement décodées
if ($payment_info) {
    // Extraire les informations nécessaires
    $product_id = $payment_info['product_id'];
    $quantity = $payment_info['quantity'];
    $customerEmail = $payment_info['customerEmail'];
    $customerFirstName = $payment_info['customerFirstName'];
    $customerLastName = $payment_info['customerLastName'];
    $customerPhoneNumber = $payment_info['customerPhoneNumber'];
    
    // Préparer l'email
    $to = 'emmanuelfosso205@gmail.com'; // Remplacez par votre adresse email
    $subject = 'Nouvelle commande de formation';
    $message = "Nouvelle commande reçue :\n\n";
    $message .= "ID du produit : $product_id\n";
    $message .= "Quantité : $quantity\n";
    $message .= "Email du client : $customerEmail\n";
    $message .= "Prénom du client : $customerFirstName\n";
    $message .= "Nom du client : $customerLastName\n";
    $message .= "Numéro de téléphone du client : $customerPhoneNumber\n";
    
    // Envoyer l'email
    mail($to, $subject, $message);
    
    // Répondre à l'API pour indiquer que la notification a été reçue
    header('HTTP/1.1 200 OK');
} else {
    header('HTTP/1.1 400 Bad Request');
}

// Connexion à la base de données
$conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insérer les données dans la base de données
$sql = "INSERT INTO community_group (product_id, quantity, customer_email, customer_first_name, customer_last_name, customer_phone_number) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iissss", $product_id, $quantity, $customerEmail, $customerFirstName, $customerLastName, $customerPhoneNumber);
$stmt->execute();
$stmt->close();
$conn->close();

?>
