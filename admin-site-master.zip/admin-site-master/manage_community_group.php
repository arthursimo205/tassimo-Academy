<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Emmanuel15";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        // Add new community group
        $name = $_POST['name'];
        $description = $_POST['description'];
        $sql = "INSERT INTO community_group (name, description) VALUES ('$name', '$description')";
        $conn->query($sql);
    } elseif (isset($_POST['delete'])) {
        // Delete community group
        $id = $_POST['id'];
        $sql = "DELETE FROM community_group WHERE id=$id";
        $conn->query($sql);
    }
}

// Fetch community groups
$sql = "SELECT * FROM community_group";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Community Groups</title>
    <link rel="stylesheet" href="stylemanage.css">
</head>
<body>
    <h1>Manage Community Groups</h1>
    
    <h2>Add New Group</h2>
    <form method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <label for="description">Description:</label>
        <textarea id="description" name="description"></textarea>
        <button type="submit" name="add">Add Group</button>
    </form>
    
    <h2>Existing Groups</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['description']; ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <button type="submit" name="delete">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <?php $conn->close(); ?>
</body>
</html>
