<?php
// admin_dashboard.php
session_start();

// Connexion à la base de données
$conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch some summary data
$sql_users = "SELECT COUNT(*) as total_users FROM users";
$sql_courses = "SELECT COUNT(*) as total_courses FROM courses";
$sql_messages = "SELECT COUNT(*) as total_messages FROM messages";

$total_users = $conn->query($sql_users)->fetch_assoc()['total_users'];
$total_courses = $conn->query($sql_courses)->fetch_assoc()['total_courses'];
$total_messages = $conn->query($sql_messages)->fetch_assoc()['total_messages'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="style1.css">
    <title>Admin Dashboard</title>
</head>
<body>

<?php
/*session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit();
} */
?>

<section id="sidebar">
    <!-- Sidebar code remains the same -->
</section>

<section id="content">
    <nav>
        <!-- Navbar code remains the same -->
    </nav>

    <main>
        <h1 class="title">Dashboard</h1>
        <ul class="breadcrumbs">
            <li><a href="#" class="active">Dashboard</a></li>
        </ul>
        <div class="info-data">
            <div class="card">
                <div class="head">
                    <div>
                        <h2><?= $total_users ?></h2>
                        <p>Utilisateurs</p>
                    </div>
                    <i class='bx bxs-user icon' ></i>
                </div>
                <span class="progress" data-value="100%"></span>
                <span class="label">100%</span>
            </div>
            <div class="card">
                <div class="head">
                    <div>
                        <h2><?= $total_courses ?></h2>
                        <p>Formations</p>
                    </div>
                    <i class='bx bxs-book icon' ></i>
                </div>
                <span class="progress" data-value="100%"></span>
                <span class="label">100%</span>
            </div>
            <div class="card">
                <div class="head">
                    <div>
                        <h2><?= $total_messages ?></h2>
                        <p>Messages</p>
                    </div>
                    <i class='bx bxs-message-square-dots icon' ></i>
                </div>
                <span class="progress" data-value="100%"></span>
                <span class="label">100%</span>
            </div>
        </div>
    </main>
</section>

<script src="script1.js"></script>
</body>
</html>
