<?php
session_start();

// Connexion à la base de données
$conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Supposons que vous avez établi une connexion à votre base de données
$description = $_POST['course_description'];
// Échapper et enregistrer la description
$description = mysqli_real_escape_string($conn, $description);
$query = "INSERT INTO courses (description) VALUES ('$description')";
mysqli_query($conn, $query);
?>
