<?php
// Inclure la connexion à la base de données
include('db_connect.php');

// Récupérer les informations d'inscription
$sql = "SELECT r.id, r.name, r.email, r.phone, r.job, r.education_level, r.experience, t.title 
        FROM registrations r
        JOIN in_person_training t ON r.training_id = t.id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table>";
    echo "<tr><th>Nom</th><th>Email</th><th>Téléphone</th><th>Métier</th><th>Niveau d'étude</th><th>Expérience</th><th>Formation</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['email']) . "</td>";
        echo "<td>" . htmlspecialchars($row['phone']) . "</td>";
        echo "<td>" . htmlspecialchars($row['job']) . "</td>";
        echo "<td>" . htmlspecialchars($row['education_level']) . "</td>";
        echo "<td>" . htmlspecialchars($row['experience']) . "</td>";
        echo "<td>" . htmlspecialchars($row['title']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Aucune inscription trouvée.";
}

$conn->close();
?>
