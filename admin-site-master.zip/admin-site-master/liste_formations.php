<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Formations</title>
    <link rel="stylesheet" href="styles.css">
    <script src="scripts.js" defer></script>
</head>
<body>
    <div class="container">
        <h1>Liste des Formations</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Catégorie</th>
                    <th>Flyer</th>
                    <th>Lien</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $conn = new mysqli('localhost', 'root', '', 'Emmanuel15');
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $result = $conn->query("SELECT * FROM courses");
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['name'] . "</td>";
                    echo "<td>" . $row['category'] . "</td>";
                    echo "<td><img src='uploads/" . $row['flyer'] . "' width='100'></td>";
                    echo "<td><a href='" . $row['link'] . "'>Lien</a></td>";
                    echo "<td><a href='modifier_formation.php?id=" . $row['id'] . "'>Modifier</a> | <a href='supprimer_formation.php?id=" . $row['id'] . "'>Supprimer</a></td>";
                    echo "</tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
        <a href="ajouter_formation.php">Ajouter une nouvelle formation</a>
    </div>
</body>
</html>
